import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AnimatePresence } from "framer-motion";
import Login from "./pages/Login";
import Register from "./pages/Register";
import FileList from "./pages/FileList";
import FileAccessList from "./pages/FileAccessList";
import UploadFiles from "./pages/UploadFiles";
import EditFile from "./pages/EditFile";
import FilePermissions from "./pages/FilePermissions";

const App = () => {
  const location = useLocation();

  return (
    <div>
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<Navigate to="/login" />} /> {/* 👈 Добавляем редирект */}
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/files" element={<FileList />} />
          <Route path="/shared-files" element={<FileAccessList />} />
          <Route path="/upload" element={<UploadFiles />} />
          <Route path="/edit/:id" element={<EditFile />} />
          <Route path="/permissions/:id" element={<FilePermissions />} />
        </Routes>
      </AnimatePresence>
    </div>
  );
};

export default App;
