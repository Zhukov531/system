import React, { useContext, useState, useEffect } from "react";
import AuthContext from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

const FileAccessList = () => {
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();
  const [accessibleFiles, setAccessibleFiles] = useState([]);

  useEffect(() => {
    if (!user) return;

    const storedFiles = JSON.parse(localStorage.getItem("files")) || [];
    const filteredFiles = storedFiles.filter(
      (file) => file.permissions && file.permissions.includes(user.email)
    );

    setAccessibleFiles(filteredFiles);
  }, [user]);

  return (
    <div>
      <h2>Файлы, к которым у вас есть доступ</h2>

      {accessibleFiles.length === 0 ? (
        <p>У вас пока нет доступных файлов</p>
      ) : (
        <ul>
          {accessibleFiles.map((file) => (
            <li key={file.id}>
              {file.name}{" "}
              <button onClick={() => navigate(`/edit/${file.id}`)}>Открыть</button>
            </li>
          ))}
        </ul>
      )}

      <button onClick={() => navigate("/files")}>Назад</button>
    </div>
  );
};

export default FileAccessList;
