import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";

const FilePermissions = () => {
  const { id } = useParams(); // Получаем ID файла из URL
  const navigate = useNavigate();
  const [file, setFile] = useState(null);
  const [users, setUsers] = useState([]); // Список пользователей с доступом
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");

  // Загружаем данные файла и список пользователей
  useEffect(() => {
    const storedFiles = JSON.parse(localStorage.getItem("files")) || [];
    const currentFile = storedFiles.find((f) => f.id.toString() === id);

    if (currentFile) {
      setFile(currentFile);
      setUsers(currentFile.permissions || []);
    } else {
      setError("Файл не найден");
    }
  }, [id]);

  // Добавление нового пользователя
  const addUser = () => {
    if (!email.trim()) {
      setError("Email не может быть пустым");
      return;
    }

    if (users.includes(email)) {
      setError("Этот пользователь уже имеет доступ");
      return;
    }

    const updatedUsers = [...users, email];
    setUsers(updatedUsers);
    updateFilePermissions(updatedUsers);
  };

  // Удаление доступа у пользователя
  const removeUser = (userEmail) => {
    const updatedUsers = users.filter((u) => u !== userEmail);
    setUsers(updatedUsers);
    updateFilePermissions(updatedUsers);
  };

  // Обновление данных файла в localStorage
  const updateFilePermissions = (updatedUsers) => {
    const storedFiles = JSON.parse(localStorage.getItem("files")) || [];
    const updatedFiles = storedFiles.map((f) =>
      f.id.toString() === id ? { ...f, permissions: updatedUsers } : f
    );

    localStorage.setItem("files", JSON.stringify(updatedFiles));
  };

  return (
    <div>
      <h2>Управление доступом</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}

      {file ? (
        <>
          <p>Файл: {file.name}</p>

          <h3>Пользователи с доступом:</h3>
          {users.length === 0 ? (
            <p>Нет пользователей с доступом</p>
          ) : (
            <ul>
              {users.map((user) => (
                <li key={user}>
                  {user}{" "}
                  <button onClick={() => removeUser(user)}>Удалить доступ</button>
                </li>
              ))}
            </ul>
          )}

          <h3>Добавить пользователя:</h3>
          <input
            type="email"
            placeholder="Введите email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <button onClick={addUser}>Добавить</button>
        </>
      ) : (
        <p>Загрузка...</p>
      )}

      <button onClick={() => navigate("/files")}>Назад</button>
    </div>
  );
};

export default FilePermissions;
