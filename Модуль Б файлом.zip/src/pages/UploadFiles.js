import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";

const UploadFiles = () => {
  const [selectedFiles, setSelectedFiles] = useState([]);
  const navigate = useNavigate();

  const handleFileChange = (event) => {
    const files = Array.from(event.target.files);
    const newFiles = files.map((file) => ({
      id: Date.now() + Math.random(),
      name: file.name,
    }));

    setSelectedFiles((prev) => [...prev, ...newFiles]);
  };

  const handleUpload = () => {
    const storedFiles = JSON.parse(localStorage.getItem("files")) || [];
    localStorage.setItem("files", JSON.stringify([...storedFiles, ...selectedFiles]));
    navigate("/files");
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.5 }}
    >
      <h2>Загрузка файлов</h2>
      <input type="file" multiple onChange={handleFileChange} />
      <ul>
        {selectedFiles.map((file) => (
          <li key={file.id}>{file.name}</li>
        ))}
      </ul>
      <button onClick={handleUpload} disabled={selectedFiles.length === 0}>
        Загрузить файлы
      </button>
      <button onClick={() => navigate("/files")}>Назад</button>
    </motion.div>
  );
};

export default UploadFiles;
