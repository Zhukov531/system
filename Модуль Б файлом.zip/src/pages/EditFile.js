import React, { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { motion } from "framer-motion";

const EditFile = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [fileName, setFileName] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    const storedFiles = JSON.parse(localStorage.getItem("files")) || [];
    const file = storedFiles.find((f) => f.id.toString() === id);
    if (file) {
      setFileName(file.name);
    } else {
      setError("Файл не найден");
    }
  }, [id]);

  const handleSave = () => {
    if (!fileName.trim()) {
      setError("Имя файла не может быть пустым");
      return;
    }

    const storedFiles = JSON.parse(localStorage.getItem("files")) || [];
    const updatedFiles = storedFiles.map((f) =>
      f.id.toString() === id ? { ...f, name: fileName } : f
    );

    localStorage.setItem("files", JSON.stringify(updatedFiles));
    navigate("/files");
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.5 }}
    >
      <h2>Редактирование файла</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <input
        type="text"
        value={fileName}
        onChange={(e) => setFileName(e.target.value)}
      />
      <button onClick={handleSave}>Сохранить</button>
      <button onClick={() => navigate("/files")}>Отмена</button>
    </motion.div>
  );
};

export default EditFile;
