import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const Register = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");

  const handleRegister = (e) => {
    e.preventDefault();

    if (password !== confirmPassword) {
      setError("Пароли не совпадают!");
      return;
    }

    // Получаем список пользователей из localStorage
    const users = JSON.parse(localStorage.getItem("users")) || [];

    // Проверяем, есть ли уже такой email
    if (users.some((user) => user.email === email)) {
      setError("Этот email уже зарегистрирован!");
      return;
    }

    // Добавляем нового пользователя в массив
    const newUser = { email, password };
    users.push(newUser);
    localStorage.setItem("users", JSON.stringify(users)); // Сохраняем в localStorage

    navigate("/login"); // Перенаправляем на страницу входа
  };

  return (
    <div>
      <h2>Регистрация</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}
      <form onSubmit={handleRegister}>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Пароль"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Повторите пароль"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
        />
        <button type="submit">Зарегистрироваться</button>
      </form>
    </div>
  );
};

export default Register;
