import React, { useContext, useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import AuthContext from "../context/AuthContext";

const FileList = () => {
  const { user } = useContext(AuthContext);
  const [files, setFiles] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const storedFiles = JSON.parse(localStorage.getItem("files")) || [];
    setFiles(storedFiles);
  }, []);

  const deleteFile = (id) => {
    setFiles((prevFiles) => prevFiles.filter((file) => file.id !== id));
  
    setTimeout(() => {
      const updatedFiles = files.filter((file) => file.id !== id);
      localStorage.setItem("files", JSON.stringify(updatedFiles));
    }, 300);
  };
  

  return (
    <motion.div
      initial={{ opacity: 0, x: -50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 50 }}
      transition={{ duration: 0.5 }}
    >
      <h2>Мои файлы</h2>
      <button onClick={() => navigate("/upload")}>Загрузить файл</button>
      <button onClick={() => navigate("/shared-files")}>Доступные файлы</button>

      {files.length === 0 ? (
        <p>Файлов пока нет</p>
      ) : (
        <ul>
          {files.map((file) => (
            <motion.li
              key={file.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.3 }}
            >
              {file.name}{" "}
              <button onClick={() => navigate(`/edit/${file.id}`)}>Редактировать</button>
              <button onClick={() => navigate(`/permissions/${file.id}`)}>Управление доступом</button>
              <button onClick={() => deleteFile(file.id)}>Удалить</button>
            </motion.li>
          ))}
        </ul>
      )}
    </motion.div>
  );
};

export default FileList;
